<?php
/**
* @version 1.0.0
* @package mod_mycelium_gear
* @copyright (C) 2015 Alexander Makarov
* @license GNU General Public License version 3 or later
* @author Alexander Makarov http://www.devplus.ru
*/

defined('_JEXEC') or die;
?>

<script type="text/javascript">
	var jQ = false;
	function initJQ() {
	  if (typeof(jQuery) == 'undefined') {
	    if (!jQ) {
	      jQ = true;
	      document.write('<scr' + 'ipt type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></scr' + 'ipt>');
	    }
	    setTimeout('initJQ()', 0);
	  }
	}
	initJQ();
</script>

<script src="https://gateway.gear.mycelium.com/gear-widget-host.js"></script>

<div>
	<iframe width="<?php echo $params->get('widget_width'); ?>" height="auto" frameBorder="0" id="gear-widget" scrolling="no" src="https://gateway.gear.mycelium.com/widgets/<?php echo $params->get('gateway_id'); ?>" data-target-domain="https://gateway.gear.mycelium.com"></iframe>
</div>
