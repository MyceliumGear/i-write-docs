<?php
/**
* @version 1.0.0
* @package mod_mycelium_gear
* @copyright (C) 2015 Alexander Makarov
* @license GNU General Public License version 3 or later
* @author Alexander Makarov http://www.devplus.ru
*/

defined('_JEXEC') or die;

$moduleclass_sfx = htmlspecialchars($params->get('moduleclass_sfx'));

require JModuleHelper::getLayoutPath('mod_mycelium_gear', $params->get('layout', 'default'));
