<?php
/**
* @version 1.0.1
* @package mod_mycelium_gear
* @copyright (C) 2015 Mycelium Gear
* @license GNU General Public License version 3 or later
* @author Mycelium Gear https://gear.mycelium.com
*/

defined('_JEXEC') or die;
?>

<script src="https://gateway.gear.mycelium.com/gear-widget-host.js"></script>

<div>
	<iframe width="<?php echo $params->get('widget_width'); ?>" height="auto" frameBorder="0" id="gear-widget" scrolling="no" src="https://gateway.gear.mycelium.com/widgets/<?php echo $params->get('gateway_id'); ?>" data-target-domain="https://gateway.gear.mycelium.com"></iframe>
</div>
