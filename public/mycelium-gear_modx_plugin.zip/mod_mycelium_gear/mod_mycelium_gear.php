<?php
/**
* @version 1.0.1
* @package mod_mycelium_gear
* @copyright (C) 2015 Mycelium Gear
* @license GNU General Public License version 3 or later
* @author Mycelium Gear https://gear.mycelium.com
*/

defined('_JEXEC') or die;

$moduleclass_sfx = htmlspecialchars($params->get('moduleclass_sfx'));

require JModuleHelper::getLayoutPath('mod_mycelium_gear', $params->get('layout', 'default'));
