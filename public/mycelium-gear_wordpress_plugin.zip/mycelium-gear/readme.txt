=== WP Mycelium Gear Widget ===

Contributors: weberix
Tags: payment, mycelium gear
Author URI:  http://weberix.com
Author: Viktoriia Oliynyk
Requires at least: 2.8
Tested up to: 4.1
Stable tag: 1.0
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Version: 1.0

Allow to use shortcode for inserting Mycelium Gear Widget in any post/page or code.

== Description ==

Allow to use shortcode for inserting Mycelium Gear Widget in any post/page or code.

== Installation ==

= Using The WordPress Dashboard =

1. Navigate to the 'Add New' Plugin Dashboard
2. Select `mycelium-gear.zip` from your computer
3. Upload
4. Activate the plugin on the WordPress Plugin Dashboard

= Using FTP =

1. Extract `mycelium-gear.zip` to your computer
2. Upload the `mycelium-gear` directory to your `wp-content/plugins` directory
3. Activate the plugin on the WordPress Plugins Dashboard

== Changelog ==

= 1.0 =
* Initial release