<?php
	class WP_Mycelium_Gear {
	
		protected $version;
	
		function __construct() {
		
			$this->version = '1.0';
		
			add_action( 'wp_enqueue_scripts', array( $this, 'register_plugin_scripts' ) );
			add_shortcode('mycelium_gear',  array( $this, 'shortcode_output') );
			
			$this->load_dependencies();
			$this->define_admin_hooks();
			
		}
	
		//add plugin scripts
		public function register_plugin_scripts() {

			wp_register_script( 'mycelium-plugin', 'http://gateway.gear.mycelium.com/widget/javascripts/gear-widget-host.js', array('jquery'), '1.0.1'  );
			wp_enqueue_script( 'mycelium-plugin' );

		}

		//load admin and widget classes
		private function load_dependencies() {
		
			require_once plugin_dir_path( __FILE__ ) . 'admin/class-mycelium-gear-admin.php';
			require_once plugin_dir_path( __FILE__ ) . 'class-mycelium-gear-widget.php';
			
		}
		
		public function shortcode_output(){
			//output shortcode with inputed data 
			$product_data = mgw_widget::get_data_products();
			Mgw_Widget::mycelium_gear_output($product_data);
		}
		
		//load admin class and define admin hooks
		private function define_admin_hooks() {
		
			$admin = new Mycelium_Gear_Admin( $this->get_version() );
			
		}
		
		public function get_version() {
			return $this->version;
		}
	
	}
	
?>
