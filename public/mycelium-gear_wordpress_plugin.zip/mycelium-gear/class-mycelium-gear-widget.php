<?php
// Creating the widget 
class Mgw_Widget extends WP_Widget {

	function __construct() {
		parent::__construct(
			// Base ID of widget
			'mgw_widget', 

			// Widget name will appear in UI
			__('Mycelium Gear Widget', 'mgw_widget_domain'), 

			// Widget description
			array( 'description' => __( 'Mycelium Gear Widget', 'mgw_widget_domain' ), ) 
		);
	}

	// Creating widget front-end
	// This is where the action happens
	public function widget( $args, $instance ) {
		$title = apply_filters( 'widget_title', $instance['title'] );
		// before and after widget arguments are defined by themes
		echo $args['before_widget'];
		if ( ! empty( $title ) ){
			echo $args['before_title'] . $title . $args['after_title'];
		}

		// This is where you run the code and display the output
		$data_products = $this->get_data_products();
		$this->mycelium_gear_output( $data_products );
		echo $args['after_widget'];
	}
	
	// WP Shortcode to display iframe.
	public function mycelium_gear_output( $data_products ){
	
		$data_gateway_id = get_option('mgw_gateway_id');
		?>
		
		<iframe data-currency="BTC" data-gateway-id="<?php echo $data_gateway_id; ?>"
		data-products="<?php echo $data_products;?>" data-price=""
		data-tagret-domain="http://gateway.gear.mycelium.com"
		data-title="" height="130px" id="gear-widget" scrolling="no"
		src="http://gateway.gear.mycelium.com/widget" style="border:
		none; display: inline-block; height: 130px;" width="270px"></iframe>
		
		<?php
	}
	
	/**
	 * return list of products
	 * as title:price,title:price,...
	 * @return string
	 */
	public function get_data_products() {
	
		$mgw_title_array = Mycelium_Gear_Admin::get_serialized_option('mgw_title');
		$mgw_price_array = Mycelium_Gear_Admin::get_serialized_option('mgw_price');
		$data_products = '';
		foreach( $mgw_title_array as $key => $mgw_title )
		{
			$data_products .= $mgw_title.":".$mgw_price_array[$key].",";
		}
		return substr( $data_products, 0, strlen( $data_products ) - 1 );
	}
			
	// Widget Backend 
	public function form( $instance ) {
		if ( isset( $instance[ 'title' ] ) ) {
			$title = $instance[ 'title' ];
		}
		else {
			$title = __( 'New title', 'mgw_widget_domain' );
		}
		// Widget admin form
		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<?php 
	}
		
	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		return $instance;
	}
} // Class wpb_widget ends here

// Register and load the widget
function mgw_load_widget() {
	register_widget( 'mgw_widget' );
}
add_action( 'widgets_init', 'mgw_load_widget' );
?>
