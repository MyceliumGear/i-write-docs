<?php

class Mycelium_Gear_Admin {

	private $version;
	
	private $plugin_slug;

	public function __construct( $version ) {
		
		$this->plugin_slug = 'mycelium-gear-widget';
		$this->version = $version;
		
		//create new top-level menu
		add_action('admin_menu', array( $this, 'mycelium_gear_menu' ) );
		
		$this->enqueue_styles();
		$this->enqueue_scripts();
		
	}

	//plugin styles
	 public function enqueue_styles() {

		wp_enqueue_style(
			'mycelium-gear-widget-admin',
			plugin_dir_url( __FILE__ ) . 'css/mycelium-gear-widget-admin.css',
			array(),
			$this->version,
			FALSE
		);

	}

	//plugin scripts
	 public function enqueue_scripts() {

		wp_register_script( 'mycelium-plugin-admin', plugin_dir_url( __FILE__ ) . 'js/mycelium-gear-widget-admin.js', array('jquery'), '1.0.1'  );
		wp_enqueue_script( 'mycelium-plugin-admin' );

	}
	
	//adding plugin settings page to admin menu
	public function mycelium_gear_menu(){
			add_menu_page( 'Mycelium Gear Widget Page', 'Mycelium Gear', 'manage_options', $this->plugin_slug,  array( $this, 'mycelium_gear_init' )  );
	}
	
	
	//output admin page for mycelium gear plugin
	public function mycelium_gear_init(){
        ?>
		<div class="mycelium_gear_wrap">
			<h2>WP Mycelium Gear Widget - Settings Page</h2>
			
			<div class="descr">Use widget to add Mycelium Gear Widget on your site or shortcode <strong>[mycelium_gear]</strong> to include payment form in any post, page or custom post type. Also you can write <strong>echo do_shortcode( '[mycelium_gear]' );</strong> in any place of your theme where you want to see the payment form. </div>
			
			<?php
			if( isset($_POST[ 'mgw_gateway_id' ])) {
			
				// Save the posted value in the database
				update_option( 'mgw_gateway_id', $_POST[ 'mgw_gateway_id' ] );
				update_option( 'mgw_title', serialize ( $_POST[ 'mgw_title' ] ) );
				update_option( 'mgw_price', serialize ( $_POST[ 'mgw_price' ] ) );
				
				// Put an settings updated message on the screen
				?>
				<div class="updated"><p><strong>Settings saved</strong></p></div>
				<?php
			}
			
			$this->form_output();
			
			?>
		</div>
		<?php
	}
	
	
	//Generate settings form code
	public function form_output(){
	?>
		<form method="post" action="">
		
			<div>
				<label for='mgw_gateway_id'>Gateway Id:</label>
				<input type="text" name="mgw_gateway_id" value="<?php echo get_option('mgw_gateway_id'); ?>" />
			</div>
			
			<?php 
			$mgw_title_array = $this->get_serialized_option('mgw_title');
			$mgw_price_array = $this->get_serialized_option('mgw_price');
			
			foreach ( $mgw_title_array as $key => $val ) { ?>
			
				<fieldset id="fieldset_<?php echo $key; ?>">
					<legend>#<?php echo $key; ?></legend>
					<div class="half">
						<label for='mgw_title'>Title:</label>
						<input type="text" name="mgw_title[]" value="<?php echo $val; ?>" />
					</div>
					<div  class="half">
						<label for='mgw_price'>Price:</label>
						<input type="text" name="mgw_price[]" value="<?php echo $mgw_price_array[$key]; ?>" />
					</div>
					<div class="sign minus" id="remove_fieldset_<?php echo $key; ?>">-</div>
				</fieldset>
				
			<?php	} ?>
			
			<div class="sign plus" id="add_fieldset">+</div>
			

			<p class="submit">
			<input type="submit" class="button-primary" value="<?php _e('Save Changes') ?>" />
			</p>

		</form>
	<?php
	}
	
	/**
     * Returns an array of unserialized option
     * @param $option_name
     * @return array
     */
	public function get_serialized_option( $option_name ){
			
			$value_array = unserialize(get_option($option_name));
			//trick for first initialization
			if( empty( $value_array ) ){
				$value_array = array('0');
			}
			return $value_array;
			
	}

}
