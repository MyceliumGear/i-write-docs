<?php

class Mycelium_Gear_Admin {

	private $version;
	
	private $plugin_slug;

	public function __construct( $version ) {
		
		$this->plugin_slug = 'mycelium-gear-widget';
		$this->version = $version;
		
		//create new top-level menu
		add_action('admin_menu', array( $this, 'mycelium_gear_menu' ) );
		
		$this->enqueue_styles();
		
	}

	//plugin styles
	 public function enqueue_styles() {

		wp_enqueue_style(
			'mycelium-gear-widget-admin',
			plugin_dir_url( __FILE__ ) . 'css/mycelium-gear-widget-admin.css',
			array(),
			$this->version,
			FALSE
		);

	}
	
	//adding plugin settings page to admin menu
	public function mycelium_gear_menu(){
			add_menu_page( 'Mycelium Gear Widget Page', 'Mycelium Gear', 'manage_options', $this->plugin_slug,  array( $this, 'mycelium_gear_init' )  );
	}
	
	
	//output admin page for mycelium gear plugin
	public function mycelium_gear_init(){
        ?>
		<div class="mycelium_gear_wrap">
			<h2>WP Mycelium Gear Widget - Settings Page</h2>
			
			<div class="descr">Use widget to add Mycelium Gear Widget on your site or shortcode <strong>[mycelium_gear]</strong> to include payment form in any post, page or custom post type. Also you can write <strong>echo do_shortcode( '[mycelium_gear]' );</strong> in any place of your theme where you want to see the payment form. </div>
			
			<?php
			if( isset($_POST[ 'mgw_gateway_id' ])) {
			
				// Save the posted value in the database
				update_option( 'mgw_gateway_id', $_POST[ 'mgw_gateway_id' ] );
				update_option( 'mgw_width', $_POST[ 'mgw_width' ]  );
				
				// Put settings updated message on the screen
				?>
				<div class="updated"><p><strong>Settings saved</strong></p></div>
				<?php
			}
			
			$this->form_output();
			
			?>
		</div>
		<?php
	}
	
	
	//Generate settings form code
	public function form_output(){
	?>
		<form method="post" action="">
		
			<div>
				<label for='mgw_gateway_id'>Gateway Id:</label>
				<input type="text" name="mgw_gateway_id" size="80" value="<?php echo get_option('mgw_gateway_id'); ?>" />
			</div>
			
			<div>
				<label for='mgw_gateway_id'>Iframe width:</label>
				<input type="text" name="mgw_width" value="<?php echo get_option('mgw_width'); ?>" />
			</div>			

			<p class="submit">
				<input type="submit" class="button-primary" value="<?php _e('Save Changes') ?>" />
			</p>

		</form>
	<?php
	}

}
