jQuery(function () {

		//add new fieldset on + click
		jQuery('#add_fieldset').click(function(){
			var fieldset_id = jQuery('.mycelium_gear_wrap fieldset').last().attr('id');
			//# of new fieldset
			var fieldset_number = parseInt(fieldset_id.substr(fieldset_id.length - 1)) + 1;
			//new fieldset html
			var new_fieldset = '<fieldset id="fieldset_'+fieldset_number+'"><legend>#'+fieldset_number+'</legend><div class="half"><label for="mgw_title">Title:</label><input type="text" name="mgw_title[]" value="" /></div><div  class="half"><label for="mgw_price">Price:</label><input type="text" name="mgw_price[]" value="" /></div><div class="sign minus" id="remove_fieldset_'+fieldset_number+'">-</div></fieldset>';
			//insert new fieldset after last fieldset
			jQuery('#'+fieldset_id).after(new_fieldset);
		});
		
		//remove fieldset on - click
		jQuery('body').on('click', '.sign.minus', function(){
			if( confirm('Do you really want to delete this item?') ) {
				jQuery(this).parent().remove();
			}
		})
		
});
