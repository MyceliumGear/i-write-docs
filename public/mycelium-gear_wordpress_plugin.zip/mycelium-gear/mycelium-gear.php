<?php
/**
 * Plugin Name: WP Mycelium Gear Widget
 * Description: Allow to use shortcode or widget for inserting Mycelium Gear Widget in any post/page or code
 * Version:     1.0
 * Author:      Viktoriia Oliynyk
 * Author URI:  http://weberix.com
 * License:     GPL v3
 * 
 * Copyright (c) 2014, weberix
 * 
 * WP Mycelium Gear Widget is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 * 
 * WP Mycelium Gear Widget is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have recieved a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses>.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // exit if accessed directly
}

require_once plugin_dir_path( __FILE__ ) . 'class-mycelium-gear.php';

$mgw = new WP_Mycelium_Gear();

?>